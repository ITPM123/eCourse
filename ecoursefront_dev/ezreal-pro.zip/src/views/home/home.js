export default {
    name: 'home',
    render() {
      return <div>我是render home</div>
    }
  }