<template>
  <div>
    <div style="font-weight:bold;font-size:2em;margin-bottom:-20px;margin-left:10px;">
            作业数据
    </div>
    <a-divider />
    <!-- <homework-data></homework-data> -->
    <router-view></router-view>
  </div>
</template>

<script>
//import homeworkData from '@/components/diagram/homeworkData.vue'
export default {
  name: 'homeworkdata',
  components:{
    //homeworkData
  }
}
</script>

<style>
</style>
