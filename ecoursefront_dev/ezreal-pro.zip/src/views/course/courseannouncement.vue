<template>
  <div>
    <div style="font-weight:bold;font-size:2em;margin-bottom:-20px;margin-left:10px;">
        课程公告
    </div>
    <a-divider />
    <router-view></router-view>
  </div>
</template>

<script>
export default {
  name: 'courseannouncement',
  
}
</script>

<style>
</style>
